g++ openmp.cpp -o mp -fopenmp
./mp $1 $2
g++ pthreads.cpp -o pt -lpthread
./pt $1 $2
